package laboratorion3;
import java.io.*;

public class LaboratorioN3 {

	static BufferedReader entrada=new BufferedReader(new InputStreamReader(System.in));
	static final String DIAS[]= {"lunes","martes","miercoles","jueves","viernes","sabado","domingo"};
	static final String CANTONES[]= {"Hojancha","Carmona","Ca�as","Bagaces","Liberia","Tilaran"};
	static final int COMISION=1050,PRECIO=10500;
	
	public static void main(String[] args) throws IOException{
		System.out.println("\t\tPROENF");
		menu();
	}
	
	
	public static void menu() throws IOException {
		
		int RutasVentas[][]=new int[6][7];
		
		int option=0;
		
		while((option<1)||(option>8)) {
			
			System.out.println("Ingrese una opcion:\n1-Ingresar informacion de las ventas\n2-Consular ventas totales semanales"
					+"\n3-Consultar comision semanal total"+"\n4-Ventas totales por dia"+"\n5-Monto comision por ruta"+"\n6-Ventas por ruta"+"\n7-Consultar ventas (Ruta Especifica)"+"\n8-Salir");
			try {
				option=Integer.parseInt(entrada.readLine());
				
				switch(option) {
					
					case 1:{
						ingresarInformacion(RutasVentas);
						option=0;
					}break;
					
					case 2:{
						ventasSemanal(RutasVentas);
						option=0;
					}break;
					
					
					case 3:{
						montoComisionTotalSemanal(RutasVentas);
						option=0;
					}break;
					
					case 4:{
						ventasTotalesPorDia(RutasVentas);
						option=0;
					}break;
					
					case 5:{
						comisionPorRuta(RutasVentas);
						option=0;
					}break;
					
					case 6:{
						ventasPorRuta(RutasVentas);
						option=0;
					}break;
					
					
					case 7:{
						consultarRuta(RutasVentas);
						option=0;
					}break;
					
					case 8:{
						System.out.println("Saliendo");
						System.exit(0);
					}break;
			
					default:{
						System.out.println("->Opcion invalida\n");
						option=0;
					}break;
				
				
				}
				
				
			}catch(Exception e) {
				System.out.println("->Entrada invalida, re-ingrese una opcion\n");
			}
		}
		
			
	}
	
	
	public static void ventasPorRuta(int matrix[][]) {
		int lasRutas[]=new int[6];
		int major=0;
		
		System.out.println(">Ventas por ruta:");
		for(int cont=0;cont<matrix.length;cont++) {
			
			for(int sec=0;sec<matrix[cont].length;sec++) {
				lasRutas[cont]+=matrix[cont][sec];
			}
			
			System.out.println("Ruta "+CANTONES[cont]+", cajas "+lasRutas[cont]+", ganancia:"+(lasRutas[cont]*PRECIO)+" colones.");
		}
		
		for(int cont=0;cont<lasRutas.length;cont++) {
			
			for(int sec=0;sec<lasRutas.length;sec++) {
				
				if(lasRutas[major]<lasRutas[cont]) {
					if(lasRutas[cont]>lasRutas[sec]){
						major=cont;
					}else if(lasRutas[cont]<lasRutas[sec]){
						major=sec;
					}else {
						major=cont;
					}	
				}
			}
			
		}
		
		System.out.println("\n>Rutas con mayor ventas de cajas y ganancia:");
		
		for(int cont=0;cont<lasRutas.length;cont++) {
			
			if(lasRutas[major]==lasRutas[cont]) {
				System.out.println("Ruta "+CANTONES[cont]+" cajas:"+lasRutas[cont]+" ganancia:"+(lasRutas[cont]*PRECIO));
			}
		}
		System.out.println("");
	}
	
	
	public static void comisionPorRuta(int matrix[][]) {
		int cantidad=0;
		System.out.println("\n>Comision por ruta:");
		for(int cont=0;cont<matrix.length;cont++) {
			cantidad=0;
			for(int sec=0;sec<matrix[cont].length;sec++) {
				cantidad+=matrix[cont][sec];
			}
			System.out.println("La ruta "+CANTONES[cont]+" tiene una comision de:"+(cantidad*COMISION)+" colones.");
		}
		System.out.println("");
	}
	
	public static void montoComisionTotalSemanal(int matrix[][]) {
		int cajas=0;
		for(int cont=0;cont<matrix.length;cont++) {
			
			for(int sec=0;sec<matrix[cont].length;sec++) {
				cajas+=matrix[cont][sec];
			}
			
		}
		
		System.out.println(">Comision total semanal pagada:"+(cajas*COMISION)+" colones.\n");
	}
	
	
	public static void ventasTotalesPorDia(int matrix[][]) {
		int losDias[]=new int[7];
		int major=0;
		
		System.out.println(">Ventas totales por dia:");
		for(int cont=0;cont<matrix[0].length;cont++) {
			
			for(int sec=0;sec<matrix.length;sec++) {
				losDias[cont]+=matrix[sec][cont];
			}
			
			System.out.println("Dia "+DIAS[cont]+", cajas "+losDias[cont]+", ganancia:"+(losDias[cont]*PRECIO)+" colones.");
		}
		
		for(int cont=0;cont<losDias.length;cont++) {
			
			for(int sec=0;sec<losDias.length;sec++) {
				
				if(losDias[major]<losDias[cont]) {
					if(losDias[cont]>losDias[sec]){
						major=cont;
					}else if(losDias[cont]<losDias[sec]){
						major=sec;
					}else {
						major=cont;
					}	
				}
			}
			
		}
		
		System.out.println("Dia(s) con mayor ventas de cajas:");
		
		for(int cont=0;cont<losDias.length;cont++) {
			
			if(losDias[major]==losDias[cont]) {
				System.out.println("Dia "+DIAS[cont]+" cajas:"+losDias[cont]);
			}
		}
		System.out.println("");
	}
	
	public static void ventasSemanal(int matrix[][]) throws IOException {
		int total=0;
		for(int cont=0;cont<matrix.length;cont++) {
			
			for(int sec=0;sec<matrix[cont].length;sec++) {
				total+=matrix[cont][sec];
			}
			
		}
		System.out.println(">En todas las rutas de esta semana:\n>se vendieron:"+total+" cajas."
				+"\n>lo que representa una ganancia efectiva de:"+(total*PRECIO)+" colones.\n");
	}
	
	
	public static void consultarRuta(int matrix[][]) throws IOException {
		System.out.println("\nConsultar una ruta");
		int option=0;
		while((option<1) || (option>6)) {
			try {
				System.out.println("1-Ruta Hojancha\n2-Ruta Carmona\n3-Ruta Ca�as\n4-Ruta Bagaces\n5-Ruta Liberia\n6-Ruta Tilaran");
				option=Integer.parseInt(entrada.readLine());
				if((option<1) || (option>6)) {
					System.out.println("->Ingrese una opcion valida.");
				}else {
					option--;
					int total=0;
					System.out.println("Ruta "+CANTONES[option]+":");
					for(int cont=0;cont<matrix[option].length;cont++) {
						total+=matrix[option][cont];
					}
					System.out.println(">Se vendieron "+total+" cajas,"+" con una ganancia de "+(total*PRECIO)+" colones.");
					option++;
				}
			}catch(Exception e) {
				System.out.println("->Entrada invalida.");
			}
		}
		System.out.println("");
	}
	
	public static void ingresarInformacion(int matrix[][]) {
		System.out.println("Ingrese la informacion: que se le solicite");
		
		for(int cont=0;cont<matrix.length;cont++) {
			System.out.println("\n\tRuta "+CANTONES[cont]+":");
			for(int sec=0;sec<matrix[0].length;sec++) {
				int option=0;
				
				while(option==0) {
					try {
						System.out.println("Cantidad de cajas para el dia "+DIAS[sec]+":");
						option=Integer.parseInt(entrada.readLine());
						//option=55;
						if((option<1) || (option>500)) {
							System.out.println("->Maximo 500 cajas, minimo 1.");
							option=0;
						}else {
							matrix[cont][sec]=option;
						}
						
					}catch(Exception e) {
						System.out.println("->Entrada incorrecta.");
					}
				}
			}//for
			System.out.println("->Datos registrados.\n");
		}
		
	}
	

}